1. development stage. ( patience data)
   api, third data---> fake / dummy data
   baseUrlDevelopement/user

2. testing stage.
   api--->baseUrlTesting/user

3. deployment stage.
   api-->realAPi-->baseUrlDeployment.

component
useState
useEffect()
useRef
routes
links
navigate
deployment
