import React from 'react'

const Home = () => {
  console.log(process.env);
  return (
    <h1>Home page</h1>
  )
}

export default Home